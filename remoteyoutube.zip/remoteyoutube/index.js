
// modules installed
// socket io
// express
// qrcode



const express = require('express');
const socketIo = require('socket.io');
const app = express();


// ServerIP.
const { networkInterfaces } = require('os');
const nets = networkInterfaces();
const results = Object.create(null); // Or just '{}', an empty object
for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
        // Skip over non-IPv4 and internal (i.e. 127.0.0.1) addresses
        // 'IPv4' is in Node <= 17, from 18 it's a number 4 or 6
        const familyV4Value = typeof net.family === 'string' ? 'IPv4' : 4
        if (net.family === familyV4Value && !net.internal) {
            if (!results[name]) results[name] = [];
            results[name].push(net.address);
        }
    }
}
const serverIP=results.en0;
const portNum = process.env.PORT || 3000;
var server = app.listen(portNum, function(){
	console.log('server started');
});
app.use(express.static(__dirname+'/public'));
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

// Create QRcode.
const QRCode = require('qrcode');
QRCode.toFile('public/imgs/qr.png', 'http://'+serverIP+':'+portNum+'/remote', {
  errorCorrectionLevel: 'H'
}, function(err) {
  if (err) throw err;
  console.log('QR code saved!');
});

// Handling GET / Request
app.get('/', function (req, res) {
    res.sendFile(__dirname + '/public/screen.html');
})
app.get('/remote', function (req, res) {
    res.sendFile(__dirname + '/public/remote.html');
})


// Sockets
var io = socketIo(server);
io.on('connection', (socket) => {
	
    socket.on('addScreen', (sid) => {
        io.emit('serverIP', serverIP+':'+portNum);
    });

    socket.on('addRemote', (sid) => {
        userRemoteList.addRemote(socket.id);
        io.emit('screenstatus', 'A new remote is added: '+socket.id);
        console.log(userRemoteList);
        io.emit('primaryremote', userRemoteList.primaryRemote());
    });

    socket.on('disconnect', function(){
        userRemoteList.removeRemote(socket.id);
        io.emit('screenstatus', 'Remote '+socket.id+' disconnected');
        console.log(userRemoteList);
        if(userRemoteList.countRemotes()==0) io.emit('goChangeChannel', 0);
        io.emit('primaryremote', userRemoteList.primaryRemote());
    });

    socket.on('updateChannel', (CH) => {
        userRemoteList.updateRemote(socket.id, CH);
        io.emit('screenstatus', 'Remote '+socket.id+' updated the channel to: '+CH);
        console.log(userRemoteList);
        
        // Only the master remote is allowed to change channels.
        // let allRemotes = userRemoteList.convertList();
        // if(allRemotes.length>0 && socket.id==allRemotes[0]) io.emit('goChangeChannel', CH);
        io.emit('goChangeChannel', CH);
    });

    socket.on('power', (Stat) => {
        // Only the master remote is allowed to power on off.
        // let allRemotes = userRemoteList.convertList();
        // if(allRemotes.length>0 && socket.id==allRemotes[0]) io.emit('power', Stat);
        io.emit('power', Stat);
    });

});


// Remote list.
// Keep track of user pressing remote buttons.
class remoteList{
    constructor(){
        this.list = Array();
    }

    // When a new remote connects, use this to add a user to the list.
    addRemote(socketID){
        this.list[socketID] = {
            channel: 0
        };
    }
    
    // On disconnect, remove the remoteID from the list.
    removeRemote(socketID){
        delete this.list[socketID];
    }

    // When user pressed button.
    updateRemote(socketID, CH){
        if(typeof this.list[socketID]!='undefined') this.list[socketID].channel = CH;
    }

    // Convert list.
    convertList(){
        let convertedList = Array();
        for (const [key, value] of Object.entries(this.list)) convertedList.push(key);
        return convertedList;
    }

    // Count the remotes
    countRemotes(){
        return this.convertList().length;
    }

    // Primary remote
    primaryRemote(){
        let tmplist = this.convertList();
        if(tmplist.length>0) return tmplist[0];
        return 0;
    }

}
var userRemoteList = new remoteList();





